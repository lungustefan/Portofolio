export default function Vscode() {
  return (
    <div class='w-full h-full bg-zinc-800'>
      <iframe src="https://github1s.com/Jadify00/Jadify00" scrolling="no" height="100%" width="100%"></iframe>
    </div>
  )
}
