export default function LoadingApp() {
  return (
    <div class='h-full w-full bg-zinc-800'>
        
    </div>
  )
}
